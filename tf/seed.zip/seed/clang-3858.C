
struct A
{
  A() : a(0) , b(true) { }
  long a;
  bool b;
};

struct B : public A
{
  B() : A() , c(0xDEADBEEF) { }
  unsigned int c;
};

int main()
{
  A a;
  B b;
  (A&)b = a;
  return (b.c != 0xDEADBEEF);
}