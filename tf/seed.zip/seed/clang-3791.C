#include <iostream>
#include <stdexcept>

template <typename T>
struct wrap {
    wrap() : t_() {}
    wrap(const T& t) : t_(t) {}

    T & get() { return t_; }
    void toss () { throw std::runtime_error("Toss"); }
    T t_;
};

int main() {
    std::cout << "Hello World" << std::endl;
    }
