
int main(){
    (true ? throw 1 : true) ? true : throw 2;
}
