
#include <string>
#include <iostream>
#include <sstream>

template<typename T> void add_field(T  const & value) {
  static int counter;
  std::cout << "template \n";
  if (++counter < 5) {// avoid crash!!
    std::stringstream tmp;
    tmp << value;
    add_field(tmp.str());
  } else {
    std::cout << "would crash here \n";
  }
}
// put this before the template and get desired behaviour
void add_field(std::string const &value) {
  std::cout << "overload\n";
}

int main () {
  add_field ( "value");
  return 0;
}
