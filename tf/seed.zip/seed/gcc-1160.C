
void foo()
{
#pragma omp parallel
    foo();
}