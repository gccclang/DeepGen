
#include <iostream>

class Foo {
  public:
    template<typename T>
    void operator()(const T& fcn) {
        std::cout << "calling fcn()..." << std::endl;
        fcn();
    }
};

void bar() {
    std::cout << "bar()" << std::endl;
}

int main() {
    Foo myFoo;
    myFoo(bar);
    myFoo(&bar);
    return 0;
}