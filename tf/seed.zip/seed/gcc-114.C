#include <stdio.h>

int main(int argc, char **argv) {
	printf("%p\n", (void *)0xdeadbeef ? : (void *)0xaaaaaa);
	return 0;
}