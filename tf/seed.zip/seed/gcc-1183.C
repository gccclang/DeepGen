
// test code

class TestFailure {
private:
  TestFailure(const TestFailure &);
public:
  TestFailure(int *p);
};

void dummy(const TestFailure &failure);

void usingfunc(int *intp) {
  // this:
  { TestFailure foo(intp);
    dummy(foo);
  }
  // should be the same as this
  dummy( TestFailure(intp) );
}