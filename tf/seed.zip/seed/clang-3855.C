struct Foo {                                                                                                                                                                                                                                                                                                                                                                
  Foo() {}
};

Foo f;

int main() {
}