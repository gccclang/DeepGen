class Obj
{
public:
  Obj ();
  Obj (const Obj &);
  ~Obj ();
  int var;
};

int foo (Obj arg)
{
  arg.var++;
  return arg.var;
}

int main()
{
  Obj obj;

  return 0;	/* initialized */
}

Obj::Obj ()
{
  var = 1;
}

Obj::~Obj ()
{
}
