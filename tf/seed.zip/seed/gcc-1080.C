
template <int N> bool f() {
  unsigned int i=0;
  return i!=N;
}

template bool f<2> ();