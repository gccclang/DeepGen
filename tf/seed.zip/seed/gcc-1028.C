

#include <vector>

namespace PatternMaster {
    struct SymbolTable {
	static const bool EMPTY_BOOLEAN = false;
    };
}

bool evaluate(std::vector<bool> value) {
    const unsigned long offset = 23;
    return (offset < value.size()
	    ? value[offset]
	    : PatternMaster::SymbolTable::EMPTY_BOOLEAN);
}