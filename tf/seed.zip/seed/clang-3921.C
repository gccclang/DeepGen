#include <stdlib.h>

int main()
{
  bool b = NULL; (void) b;
  char c = NULL; (void) c;
  int i = NULL; (void) i;
  return 0;
}
