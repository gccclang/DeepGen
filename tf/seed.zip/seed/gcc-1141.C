
template <int i>
struct c
{};

template <typename T>
struct a
{
  static int const i = 0;

  void f(c<i>);
};

template <typename T>
void
a<T>::f(c<i>)
{}