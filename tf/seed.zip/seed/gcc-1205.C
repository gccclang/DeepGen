
typedef int value_type;
const value_type b = 0x80000000;
const value_type e1 = b + 1;
const value_type e2 = b + 2;
const value_type e3 = b + 3;
const value_type e4 = b + 4;
const value_type e5 = b + 5;
int main (value_type error)
{
  switch (error)
  {
   case e1: return 0;
   case e2: return 0;
   case e3: return 0;
   case e4: return 0;
   case e5: return 0;
 }
}