
class A {};
class B : public A {};

static inline int foo(A *const d)
{ return 0; }

static inline int foo(const A *const d)
{ return 1; }

int main()
{
    B *const d = 0;
    return foo(d);
}