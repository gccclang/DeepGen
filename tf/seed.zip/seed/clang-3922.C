#include <cstdio>
struct a { int a : 10, b : 10; };
static a x;
const int &y = x.a;
int main() { x.b = 100; printf("%d\n", y); }