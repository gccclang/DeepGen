#include <new>

template <typename TYPE>
void f()
{
    typedef TYPE TArray[7];

    TArray x;
    new(&x) TArray();
}

int main()
{
    f<char>();
    f<int>();
}