struct A {
  unsigned int i;
  volatile int buff[2];
};

int main(int argc, char** argv) {
  A a1, a2;
  a1 = a2;
  return 0;
}