#include <stdio.h>

char str[] = "abc";

const char *a1 = str;
struct A { operator const char *() {return str;} } a2;

volatile char *b1 = str;
struct B { operator volatile char *() {return str;} } b2;

int
main()
{

  printf ("%p\n", a1);
  printf ("%p\n", b1);
  printf ("%p\n", (const char *)a2);
  printf ("%p\n", (volatile char *)b2);

  printf ("%d\n", a1 - b1);
  printf ("%d\n", (const char *)a2 - (volatile char *)b2);
  printf ("%d\n", a2 - b2);  // error reported here

  return 0;
}