#include <stdio.h>

class A
{
public:
    virtual ~A()
    {
        printf("~A()\n");
    }
};

class B : public A
{
public:
    virtual ~B()
    {
        printf("~B()\n");
    }
};

template<int> void test()
{
    B * b = new B;

    A * a = reinterpret_cast<A*>(b);
    a->~A();

    ::operator delete(b);
}

int main(void)
{
    test<0>();

    return 0;
}