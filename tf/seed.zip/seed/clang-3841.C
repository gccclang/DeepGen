
#include <stdio.h>
int main() {
    puts(0);
    if (const char* msg = "") {
        goto label;
    } else
    label:
        puts(msg); 
}