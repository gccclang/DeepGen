
struct A;
struct B { B (A); };
struct A { A (int); ~A (); };

void
foo (int x)
{
  A d(0);
  B e(d);
}
