class WithFriends {
	friend void do_something() { }
};


int main(int, char**)
{
}