
struct A
{
  static int foo() { return 0; }
};


template <class TYPE>
class C
{
public:
  C ();
  int (*f_)(void);
};


template <class TYPE>
C<TYPE>::C ()
  : f_ (A::foo)
{
}


void open ()
{
  C<int> th;
}