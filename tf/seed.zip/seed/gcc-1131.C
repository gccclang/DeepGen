
#include <stdio.h>

#define INT_INVALID -1

class Test
{
  int b : 16;
  int a;
  int c : 16;

public:
  Test()
  {
        b = a = c = INT_INVALID;
        //a = b = c = INT_INVALID;
  }

  void dump()const
  {
        printf("a: %d\tb: %d\tc: %d\n",a,b,c);
  }
};

int main()
{
    Test a;
    a.dump();
    return 0;
}