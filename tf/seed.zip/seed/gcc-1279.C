
struct A { };

namespace {

void thisThrows () {
  throw A();
}

struct SomeRandomType {};
}

int main() {
  try {
    thisThrows();
  }
  catch (SomeRandomType) {
    throw;
  }
  catch (A) {
  }
  return 0;
}
