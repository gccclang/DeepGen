
template<class I1, class I2>
struct iterator_restrict_traits {
  typedef I1 iterator_category;
};

template<class T>
struct scalar_expression {
  typedef T value_type;
};

template<class E, class F>
class vector_scalar_unary:
  public scalar_expression<typename F::result_type> {
public:
  typedef typename F::result_type value_type;
  typedef typename E::const_iterator::iterator_category iterator_category;

  operator value_type () const {
    return evaluate (iterator_category ());
  }
};
    
template<class E1, class E2, class F>
class vector_scalar_binary:
  public scalar_expression<typename F::result_type> {
public:
  typedef typename F::result_type value_type;
  typedef typename iterator_restrict_traits<typename E1::const_iterator::iterator_category,
									 typename E2::const_iterator::iterator_category>::iterator_category iterator_category;

  operator value_type () const { 
    return evaluate (iterator_category ());
  }
};