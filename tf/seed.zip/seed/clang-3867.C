
class B {
  int b;
};
class D : virtual B {
  int d;
public:
  void f(int i);
};
void D::f(int i) {
  d = i + 5;
}
int main() {
  D xx;
  xx.f(1);	
}
