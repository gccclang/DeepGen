

template <int i>
class A
{
public:
   static bool foo();
   template <class J>
   static bool foo();
};

template <int i>
bool A<i>::foo() { return true; }

template <int i>
template <class J>
bool A<i>::foo() { return true; }
