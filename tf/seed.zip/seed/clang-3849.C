
int main() {
  asm volatile ("":::"memory");
}