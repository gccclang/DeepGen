
#include <stdio.h>
#include <typeinfo>

class _A12345 {
  virtual ~_A12345() {}
};

extern "C" {
  void foo() { }
  void foo2() { }
}

#define ClassName _A12345

int main() {
  printf("%s\n",typeid(ClassName).name());
  printf("%s\n",typeid(foo).name());
  printf("%s\n",typeid(foo2).name());
  return 0;
}