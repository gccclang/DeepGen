
#include <cstdio>

class foo {
public:
  virtual void f() { printf("foo\n"); }
  virtual void g() const { printf("foo\n"); }
};

class bar : public foo {
public:
  void f() const { printf("bar\n"); }
  void g() const { printf("bar\n"); }
};

int main() {
  foo *b = new bar();
  b->f();
  b->g();
  return 0;
}
