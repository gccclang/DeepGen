
template <int> struct foo;

template<>
struct foo<0>
{
  typedef int t;
};

int main()
{
  1 << typename foo<0>::t(42);
}
