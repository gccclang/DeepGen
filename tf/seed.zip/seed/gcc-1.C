
template<typename T>
struct A {
  typedef A type;
};
                                                                               
                            
template<typename T>
struct B : A<T> {
  using typename A<T>::type;
  type f(type);
};