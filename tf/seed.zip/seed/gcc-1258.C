
class A {};
class B : public A {};

int main()
{
	throw (A) B();
	return 0;
}