
extern "C" int printf (...);

class allocator {
public:
  allocator()  {}
  allocator(const allocator&)  {}
  ~allocator()  {}
};

class basic_string
{
public:
  struct _Alloc_hider : allocator {};
  _Alloc_hider _M_dataplus;
};


class d0_String
  : public basic_string
{
public:
  d0_String (const char* s) { printf ("ctor %x\n", this); }
  ~d0_String () { printf ("dtor %x\n", this); }
};


struct pair {
  pair(const d0_String& __a) {}
};



int main ()
{
  pair pp[] = {
    pair (d0_String ("i")),
    pair (d0_String ("j"))
  };
  return 0;
}