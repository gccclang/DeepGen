struct A;
struct B;
extern A *f();
void a() { (B *) f(); }
