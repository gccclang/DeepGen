
struct A { A (); ~A (); };
struct B { B (); };

float d, e;

void
foo ()
{
  A a;
  float c = d;
  while (1)
    {
      B b;
      e = c ? -c : 0;
    }
}
