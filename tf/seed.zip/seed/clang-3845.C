
extern char dummy;

template<char&>
void f() {}

int main()
{
    f<dummy>();
}