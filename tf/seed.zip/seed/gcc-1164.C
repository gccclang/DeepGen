struct a {
  int b;
  a(int) {
    --b;
  }
};

int c;
int main() { a d(c); }