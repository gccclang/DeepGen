#include <stdio.h>

int main() {
  void *p0 = (void*) (int) 0xdeadbeef;
  printf("p0: %p\n", p0);
  return 0;
}