
#include <string>
class E {
public:
  E() { throw std::string("except"); }
};
int main(){
  throw E();
}
