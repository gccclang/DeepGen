

template <typename Var>
class A
{
	public:
		double getA() {return A_val;}
	protected:
		double A_val;
};