
int toupper (int);
namespace std {   using ::toupper; }

void foo()
{
  using std::toupper;
}