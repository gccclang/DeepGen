

 template<class T> class __attribute__((visibility("default"))) Foo
 {
   Foo<T> bar();
 };

 template<class T> Foo<T> Foo<T>::bar()
 {
 }
