#include <vector>

template<template<typename U, typename = std::allocator<U> > class container,
         typename DT>
container<DT> initializer(const DT& d)
{
  container<DT> t;
  t.insert(t.end(), d);
  return t;
}

int main(int, char *[])
{
  std::vector<int> v = initializer<std::vector>(5);
  v.clear();

  return 0;
}