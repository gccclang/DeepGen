
template <class T>
struct templated_struct 
{
	int count;
};

template <class T>
int template_func()
{
	templated_struct<T> s;
	if (s.count < 0) return 0;
	return 0;
}

int main()
{
	template_func<int> ();
	return 0;
}