
#include <cstddef>

template <typename> struct S {
    int i, j;
    static const unsigned int value = offsetof(S,j);
};