
struct W { };
struct X : public W { };
struct Y : public W { };
struct Z : virtual public X, public Y { };
struct ZZ : public Z {
    int i;
    int func() { return 0;};
};

int main(void) {
    ZZ zz;
    return 0;
}