class A {} a;
A& g = a;

#define g_A &g

int main() {
  if (g_A)
    return 1;
  return 0;
}
