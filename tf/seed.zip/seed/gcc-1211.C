
#include<iostream>
#include<cctype>

int main()
{
  std::cout << isdigit(0);
}