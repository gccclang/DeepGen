
namespace std
{
template <class _Arg, class _Result>
struct unary_function {
  typedef _Arg argument_type;   
  typedef _Result result_type;  
};
template <class _Arg1, class _Arg2, class _Result>
struct binary_function {
  typedef _Arg1 first_argument_type;   
  typedef _Arg2 second_argument_type;  
  typedef _Result result_type;         
};      

template <class _Operation> 
class binder1st
  : public unary_function<typename _Operation::second_argument_type,
                          typename _Operation::result_type> {
protected:
  _Operation op;
  typename _Operation::first_argument_type value;
public:
  binder1st(const _Operation& __x,
            const typename _Operation::first_argument_type& __y)
      : op(__x), value(__y) {}
  typename _Operation::result_type
  operator()(const typename _Operation::second_argument_type& __x) const {
    return op(value, __x); 
  }
};

template <class _Operation, class _Tp>
inline binder1st<_Operation> 
bind1st(const _Operation& __fn, const _Tp& __x) 
{
  typedef typename _Operation::first_argument_type _Arg1_type;
  return binder1st<_Operation>(__fn, _Arg1_type(__x));
}

template <class InputIterator, class OutputIterator, class UnaryOperation>
inline
OutputIterator
transform(InputIterator , InputIterator ,
          OutputIterator r, UnaryOperation)
{
  OutputIterator result = r;
  return result;
}

}
namespace mtl
{
template<class T, unsigned int thesize>
class carray {
  private:
    T v[thesize];  
  public:
    typedef T        value_type;
    typedef T*       iterator;
    typedef const T* const_iterator;
    iterator begin() { return v; }
    iterator end() { return v+thesize; }
};

}

namespace mtl_algo {
template <class InputIterator, class OutputIterator, class UnaryOperation>
inline
OutputIterator
transform(InputIterator , InputIterator ,
          OutputIterator r, UnaryOperation)
{
  OutputIterator result = r;
  return result;
}

}
namespace mtl {

template <class S, class T, class R>
struct mtl_multiplies : std::binary_function<S, T, R> {
  typedef S first_argument_type;
  typedef T second_argument_type;
  typedef R result_type;
  R operator () (const S& x, const T& y) const { return x * y; }
};

template <class Vector, class T> inline
void
scale(Vector& x, const T& alpha)
{
  typedef typename Vector::value_type VT;
  mtl_algo::transform(x.begin(), x.end(), x.begin(),
                      std::bind1st(mtl_multiplies<T,VT,VT>(), alpha));
}

} 

int main ()
{
  typedef mtl::carray<double,5> compVec;
  compVec c;
  mtl::scale(c,2.0);
}
