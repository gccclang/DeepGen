int main() {
  char *ptr = new char[42];
  delete [] ptr;
}