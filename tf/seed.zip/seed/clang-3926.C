
#include <exception>

int main () {
  bool cond = false;

  try { }
  catch (std::exception& e) {
    if (cond) {
      throw e;
    }
    try { } catch (std::exception& e2) { }
  }
}
