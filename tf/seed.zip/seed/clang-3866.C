
template <typename T>
class List {
public:
  List(){
  }
};

template<typename T>
class BinomialNode {
public:
  BinomialNode(T value) {}
  List<BinomialNode<T>*> nodes;
};

int main() {
    BinomialNode<int> *node = new BinomialNode<int>(1);
}
