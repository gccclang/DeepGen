
struct D { virtual D& f(); };

void
g()
{
  D d;
  d.f().f().f().f().f().f().f().f().f().f().f().f().f().f().f().f().f().f().f().f().f().f().f().f().f().f();
}
