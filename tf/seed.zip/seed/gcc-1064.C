
class ccc {
public:
	union {
		int i;
	};
};