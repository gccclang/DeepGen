template <typename T>
void fun(T, void* = 0) {}

int main()
{
  fun(0);
}