
template < typename > void *
bar (int *p)
{
  union
    {
      int *p;
    }
  u;
  u.p = p;
  return u.p;
}

void
foo (int *p)
{
  bar < void >(p);
}
