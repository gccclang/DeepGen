
struct dummy { };
struct true_type { struct dummy i[120]; };

extern true_type y;
extern void xxx (true_type c);

void
yyy (void)
{
  xxx (y);
}

