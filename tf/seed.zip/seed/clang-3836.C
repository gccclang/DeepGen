
int main (void)
{
	double foo[4096];
	((char *)(foo))[(sizeof(foo)-1)] = '\0';
	
	return 0;
}