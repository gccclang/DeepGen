
struct A { void f() { } };
struct B: public A { };

typedef void (B::*bp)();

int main()
{
  bp b = &A::f;
}
