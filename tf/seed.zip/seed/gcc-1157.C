
struct S
{
  static __thread int *p;
};

template <int N>
struct T
{
  static __thread int *p;
};

int *
foo ()
{
  return S::p;
}

int *
bar ()
{
  return T<0>::p;
}
