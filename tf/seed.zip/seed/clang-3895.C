
#include <algorithm>

struct Foo {
	Foo(const char* s) { }
};

struct Bar {
	Bar(const char* s) { }
};

template<class X>
void ook(const char* s)
{
	X x(s);
}

int main(int argc, const char** argv)
{
	void (*f)(const char*) = argc > 1 ? ook<Foo> : ook<Bar>;
	std::for_each(argv, argv + argc, f);
}