
template<class T>
class A {
    void foo() {};
};