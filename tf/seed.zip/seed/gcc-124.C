

struct Block
{
  public:
  Block ();
  ~Block ();
};

bool func (bool bar)
{
  Block block;
  bool foo = false;

  if (!foo || bar)
    do
      {
	return true;
      }
    while (0);
  else
    do
      {
	return false;
      }
    while (0);
}
