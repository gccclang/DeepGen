int main(void)
{
  int z = 0;
  int x = 1 / z;
  (void)x;
  int y = 1 / 0;
  (void)y;
  return (0);
}