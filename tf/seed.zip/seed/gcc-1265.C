
#include <iostream>

class A{
	friend void load (A* a, float& t){
		reinterpret_cast<unsigned int&>(t) = 1077936128; //binary float value of 3
	}
};

class B{
	friend void load (B* b, float& t);
};

void load (B* b, float& t) {
	reinterpret_cast<unsigned int&>(t) = 1077936128; //binary float value of 3
}

int main(){
	float testValue = -1;
		
	//OK
	load(new A(), testValue);
	std::cout<<testValue<<std::endl;
	std::cout<<testValue<<std::endl;
	
	//FAIL
	load(new B(), testValue);
	std::cout<<testValue<<std::endl;
	std::cout<<testValue<<std::endl; //output a different value!!!!
	
	return 0;
}
