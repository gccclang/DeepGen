struct Base {virtual int Foo() {return 0;}};
struct Derived : Base {virtual int Foo() {return 1;}};
int bar(Base* b) {
  return (static_cast<Derived*>(b)->*(&Derived::Foo))();
}

// From here is for illustration:
#include <iostream>
struct MoreDerived : Derived { virtual int Foo() {return 2;}};
int main() {
  MoreDerived d;
  std::cout << bar(&d) << '\n';
}