int count;
struct A { 
  virtual void f() {}
};
struct B {
  virtual ~B() {
    count += b;
  }
  int b;
};
struct C : A, B {
  virtual ~C() {
    count += c;
  }
  int c;
};
int main() {
  C *p = new C();
  p->b = 2;
  p->c = 3;
  delete p;
  return count;
}