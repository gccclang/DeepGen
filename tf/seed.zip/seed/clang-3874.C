
extern "C" { extern int puts(const char *s); }
struct V {
  ~V() 
  {
   puts("~V()");
  }
};

int main() {
	V y;
	throw 1;
}