
class Base
{
public:
  Base() {}
  virtual ~Base() {}
};

class MyClass : public Base
{
public:
  class init_error {};
  
public:
  MyClass();
};

MyClass::MyClass()
  : Base()
{
  try {
    int x = 0;
    x++;
  } catch(...) {
    throw init_error();
  }
}