
#ifndef HANDLER_H
#define HANDLER_H
class H1 { public: virtual void foo() { } };
class H2 { public: virtual void start() = 0; };
class H12 : public H1, public H2 { public: void start(); };
#endif


void H12::start()
{
}


int main()
{
        H12 hnd;
        H2* h2 = &hnd;
        h2->start();
        return 0;
}