
template <class T> struct S { T foo (); T bar (); };
template <class T> T S<T>::foo () { return T (); };

#ifndef MAIN
template struct S<int>;
#else
extern template struct S<int>;
int main ()
{
    return S<int>().foo () + S<int>().bar () ;
}
#endif

template <class T> T S<T>::bar () { return T (); };
