

#include <stdio.h>
#include <stdint.h>

int main(int argc, char **argv) {
  unsigned int type = 'foo ';
  fprintf(stderr, "%u\n", type);
	return 0;
}