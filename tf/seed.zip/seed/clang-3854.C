template<typename T>
class X
{
public:

    X() : i(0) { } 

    void foo()
    {   
        throw 
            i == 0u ? // this causes the assertion
            5 : 6;
    }   

private:
    int i;
};

int main()
{
    X<int> x;
}