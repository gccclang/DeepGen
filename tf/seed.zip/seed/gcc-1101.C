
namespace A {};

namespace OtherNamespace {

  typedef struct {
    int member;
  } A; // conflict with A namespace!!!

}; // end of namespace

int main() {
  return 0;
}
