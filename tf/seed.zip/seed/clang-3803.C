
template <typename T>
class ClassTemplate {
  friend void T::func();
};

class C {
 public:
  void func() {
    ClassTemplate<C> ct;
  }
};

int main() {
  C c;
  c.func();
}
