
struct foo {
  int i;
};

typedef int foo::*PMI;

int main() {
  PMI x = 0;
  x = &foo::i;
}