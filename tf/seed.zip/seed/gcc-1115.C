
class foo {
  friend void bar () {}
  foo baz () {}
};
