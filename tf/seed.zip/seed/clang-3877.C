
#include <map>
#include <string>

struct T {
  std::string Name;
public:
  explicit T(const std::string &N) : Name(N) {}
};

int main(int argc, char **argv) {
  std::map<std::string, T*> Defs;
  T *M = new T("oops");
  Defs.insert(std::make_pair(M->Name, M));
  std::map<std::string, T*>::iterator I = Defs.begin();
  delete I->second;
  return 0;
}