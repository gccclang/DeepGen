
#include <typeinfo>

extern "C" void abort();
extern "C" int printf(const char*, ...);

struct A { virtual ~A() { } };
struct B : A { virtual ~B() { } };

int main() {
  A *a = new A();
  try {
    (void)dynamic_cast<B&>(*a);
    printf("Survived dynamic_cast?\n");
    abort();
  } catch (const std::bad_cast &) {
    // Okay
    return 0;
  }

  printf("Did not catch std::bad_cast?\n");
  abort();
  return 0;
}