
  #include <vector>

  int time;

  int main() {}