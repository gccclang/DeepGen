

	template <class T>
	class A {
	    static const int a=17;  // #1
	    A( const A& );          // #2    
	};

	extern template class A<int>;
	template class A<int>;