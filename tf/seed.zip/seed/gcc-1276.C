
template <typename...>
class A;

class B
{
  B (const int &, const A<int, int> &);
};

B::B (const int &, const A<int, int> &)
{
}
