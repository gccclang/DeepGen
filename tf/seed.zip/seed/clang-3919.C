template<typename T>
T accumulator(T v) {
  return v;
}

template<typename T, typename... Args>
T accumulator(T first, Args... args) {
  return first + accumulator(args...);
}

int main()
{
long sum = accumulator(1, 3, 5, 7);
return sum;
}