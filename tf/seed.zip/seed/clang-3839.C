#include <cstdio>

template <const char (*STR)[5]>
unsigned TestBug()
{
	return sizeof(*STR);
}

extern const char g_meow[5] = "meow";

int main()
{
	std::printf("%u\n", TestBug<&g_meow>());
	return 0;
}