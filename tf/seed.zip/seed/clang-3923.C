struct Debug {
 const Debug& operator<< (unsigned a) const { }
};
Debug dbg;
int main(void) {  dbg << 32 ;}