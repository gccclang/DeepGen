
#include <iostream>

int main()
{
    std::cout << std::endl;
}