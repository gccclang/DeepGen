
class test
{
    bool fii(test* other)
    {
        if (!other) return false;
    }

};
