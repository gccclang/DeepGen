
struct foo {
};

struct bar {
  bar(foo x);
};

bar y(foo());

int main(void) {
  bar x(foo());
  return 0;
}