
struct A {
        int a;
        virtual void f(){};
} ;
struct B: virtual A {};

B d;