int main()
{
    return (int() & int());
}