
class X { 
    X (const X&); 
  public: 
    X (); 
}; 
 
class Y : public X { 
  public: 
    Y (); 
}; 
 
void f(const X&); 
 
int main () { 
  f(Y()); 
}