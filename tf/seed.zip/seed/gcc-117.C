
struct B {};
struct C : virtual B { int B; };

struct D : virtual B, C {
      D() {}
      int ca;
};