
  extern "C" { int printf(const char *format, ...); };
  
  struct Test {
    Test() : i(10) {}
    Test(int i) : i(i) {}
    int i;
  private:
    int j;
  };
  
  int main() {
    Test partial[3] = { 1 };
    printf("%d %d %d\n", partial[0].i, partial[1].i, partial[2].i);
  
    Test empty[3] = {};
    printf("%d %d %d\n", empty[0].i, empty[1].i, empty[2].i);
  }