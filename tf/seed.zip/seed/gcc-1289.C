
	template <class T>
	class a
	{
	private:
		void foo() { }
		typedef void (a::*unspecified_bool_type)();
	public:
		operator unspecified_bool_type() const;
	};

	template <class T>
	inline
	a<T>::operator typename a<T>::unspecified_bool_type() const
	{
		return 0;
	}

	int main()
	{
		if( a<int>() )
		{
		}
		return 0;
	}