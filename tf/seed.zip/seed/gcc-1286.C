

struct s
{
private:
   void f(){ i = j; }
public:
   int i;
   int j;
};


int main()
{
   s a = {0, 0};
   (void) a;
}