
struct foo
{ 
  int a;

  struct bar
  { int foo::* b ;};

  static const bar bars[];

  int bad ()
  {
    this->*(bars[0].b) = 42; // error: assignment of read-only location
  }
};

const foo::bar foo::bars[] = { { &foo::a } };

int main ()
{ }