
struct X {
  char &operator[](char i);
  operator char *();
  operator const char *() const;
};

void f(X &x)
{
  x[0] += 1;
}