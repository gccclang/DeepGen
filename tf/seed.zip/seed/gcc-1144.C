

#include <iostream>

struct S {
  int i;
  short s;
};

struct T : public S {
  short t;
};

struct U {
  int i;
  short s;
  short t;
};

int main (void)
{
  if (sizeof (T) == sizeof (U))
     std::cout << "PASSED\n";
  else
     std::cout << "FAILED  " << sizeof(T) << "!=" << sizeof (U) << std::endl;
  
  return 0;
}