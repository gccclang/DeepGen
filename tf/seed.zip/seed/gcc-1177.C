
struct a_vis{};
struct a_ref{};
struct no_nest
{};
template<typename Referent>
struct non_nested_owner
{
    typedef no_nest nester ;
};
template<typename Visitor>
struct curry_visitor_referent
{
    template<typename Referent>
    struct owner
    {   
        typedef curry_visitor_referent<Visitor> nester;
    };
};
template<typename Nester, typename Referent>
struct nester_referent
{
    nester_referent(void){}
};
template<typename Visitor, typename Referent>
struct nester_referent<curry_visitor_referent<Visitor>, Referent>
{
    nester_referent(void){}
};
template<typename OwnerReferent>
struct nested_deduction
{
    nested_deduction(void){}
};
template<template<typename>class OwnerTmpl, typename Referent>
struct nested_deduction<OwnerTmpl<Referent> >
: public nester_referent<typename OwnerTmpl<Referent>::nester, Referent>
{
    nested_deduction(void){}
};
int main(void)
{
    nested_deduction<non_nested_owner<a_ref> > non_nested;
    nested_deduction<curry_visitor_referent<a_vis>::owner<a_ref> > yes_nested;
    return 0;
}
