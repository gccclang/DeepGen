
#include <iostream>
struct s{
        s(bool& bb) : i(0), b(bb), j(0) {}
    int i;
    bool& b;
    int j;
    };

bool    f(s s1, s s2, s s3, int k) {
            s3.b = true;
            return false;
            }
int main() {
        bool bz = false;
        s sz(bz);
        sz.b |= f(sz, sz, sz, 3);
        std::cerr << sz.b << "\n";;
        return 0;
        }