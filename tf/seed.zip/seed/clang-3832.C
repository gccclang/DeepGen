struct Base { int a; };
struct Derived : Base  { int a; };
int main() { }