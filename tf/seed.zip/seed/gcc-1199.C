
struct A
{
    friend void foo() {}
    friend void foo();
};