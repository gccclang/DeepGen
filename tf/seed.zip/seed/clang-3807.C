#include <stdio.h>

class A {
public:
	int a;
};

class B : public A {
public:
	int b;
};

void go(A b[2]) {
	fprintf(stderr, "%d %d\n", b[0].a, b[1].a);
}

int main() {
	B bs[2];
	bs[0].a = 1;
	bs[0].b = 2;
	bs[1].a = 3;
	bs[1].b = 4;
	go(bs);
}
