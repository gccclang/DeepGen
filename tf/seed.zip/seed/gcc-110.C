extern "C" {
  extern int isnan (double __value) throw () __attribute__ ((__const__));
}

int main()
{
    double v = 0;
    const bool b = isnan(v);
}