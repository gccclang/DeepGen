
void foo1() { __builtin_printf ("foo\n"); }
#pragma GCC visibility push(hidden)
void foo2() { __builtin_printf ("foo\n"); }
#pragma GCC visibility pop

int main() { foo2(); return 0; }

