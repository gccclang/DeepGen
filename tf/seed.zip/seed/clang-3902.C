
#include <iostream>

static int copies = 0;

struct CopyCounter {
  CopyCounter() { }
  CopyCounter(const CopyCounter &obj) {
    copies++;
  }
};

CopyCounter foo() {
  return CopyCounter();
}

int main(int argc, char **argv) {
  CopyCounter a(foo());
  std::cout << copies << '\n';
  return 0;
}