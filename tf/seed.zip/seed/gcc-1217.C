
template <class T>
struct Example {
                        void f (double);
    template <class U>  void f (U);
};

// specialize class template member function -- ambiguous?
template <>             void Example<double>::f (double);

// specialize class template member function template -- ok!
template <> template <> void Example<double>::f<double> (double);