struct List {
  List() {
  }
};

template<typename T>
struct BinomialNode {
  BinomialNode(T value) {}

  List nodes;
};

int main() {
  BinomialNode<int> *node = new BinomialNode<int>(4);
}