
struct foo1{
  template<typename T> struct foo2{};
};

struct foo3 {
  typedef foo1::template foo2<int> foo2int;
};
