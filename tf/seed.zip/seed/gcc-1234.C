
struct A { 
  virtual bool operator== (const A &a) const; 
  virtual bool operator!= (const A &a) const; 
}; 
inline bool A::operator!= ( const A &a) const 
{ return !(*this == a); } 
bool breakme(const A& newPath, A &b) 
{ return A(newPath) != b; }