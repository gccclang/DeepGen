
int main(){throw 0;}
