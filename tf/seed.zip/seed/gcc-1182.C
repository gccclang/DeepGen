
template <class T>
struct W {
  template <class S> static S getAsS(const T &v_orig);
};

template <>
template <class S>
inline S W<float>::getAsS(const float &v_spec)
{
    return S(v_spec);
}