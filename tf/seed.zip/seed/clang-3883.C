
struct A
{
    void move() {}
};

int main()
{
    A a;
    a.move();
}