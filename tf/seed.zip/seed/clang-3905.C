
struct A {
  int a;

  void f() {
    char i[sizeof(a)]; // Works fine
    enum { x = sizeof(i) }; // Works fine
    enum { y = sizeof(a) }; // Compile error
  }
};

int main() {
  return 0;
}