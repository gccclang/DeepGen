
#include <iostream>
using namespace std;

class Base {
public:
  const static int A = 0;
  const static int B = 1;
};

class Child : public Base {
public:
  void printAB(bool v);
};


void Child::printAB(bool v) {
  int a = (v)?A:B;
  int b = (v)?A:B;

  cout<<"a is "<<a<<" b is "<<b<<endl;
}

int main() {
  Child c;
  c.printAB(true);
  c.printAB(false);
}
