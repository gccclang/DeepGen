
#include <list>

struct Derived: private std::list<int> {
  using std::list<int>::iterator;
  using std::list<int>::const_iterator;
  using std::list<int>::begin;
};

void foo() {
  Derived d;

  Derived::iterator       b = d.begin();
  Derived::const_iterator c = d.begin();
}