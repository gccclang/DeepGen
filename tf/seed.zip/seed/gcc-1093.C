
namespace ns {
  struct A {
    void operator() (A *);
    A (int);
  };
  A m ();
}

struct B {
  B() {
    ns::A m (0);
    m ((ns::A *)0);
  }
};