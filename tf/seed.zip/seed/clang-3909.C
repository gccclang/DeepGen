
#include <iostream>

struct I
{
  virtual void F() const = 0;
};

void Go(const I &i)
{
  i.F();
}

int main()
{
  if (true)
  {
    struct C : I
    {
      void F() const { std::cout << "A" << std::endl; }
    };
    Go(C());
  }
  if (true)
  {
    struct C : I
    {
      void F() const { std::cout << "B" << std::endl; }
    };
    Go(C());
  }
}
