int f (int const & p) { return p; }

template < typename T > void g (T) { int a[f(1)]; }

int main ()
{
  g < int > (1);
  return 0;
}