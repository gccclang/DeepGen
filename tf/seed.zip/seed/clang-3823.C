
template <int dim>
class B
{
  public:
    B(const unsigned char i);
    unsigned char value : (dim > 0 ? dim : 1);
};

template <int dim>
inline
B<dim>::B(const unsigned char i)
		: value(i)
{}

int main()
{}