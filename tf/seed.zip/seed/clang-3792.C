
struct Base {
	virtual void func() {}
protected:
	~Base() {}
};

struct Derived : Base {};

int main() {
	Derived * foo = new Derived;
	delete foo;
}