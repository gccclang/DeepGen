
template <class T>
struct Example {
    template <class U>  void operator= (U);
};

// specialize class template member function template 
template <> template <>
void Example<double>::operator=<double> (double);