
#include <string>
#include <iostream>

int main() {
  int i = 6;
  std::string s;
  s = i;
  std::cout << s << "\n";
}