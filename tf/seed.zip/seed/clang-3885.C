
struct Base {
        virtual ~Base() { }
};
struct Derived : public Base { };

int
main(void)
{
        Derived d;
        Base *b = new Derived(d);

        delete b;
}