

struct A
{
    int i[6];
    A () : i() {}
};

struct B
{
    A a;
    B(const A& x) : a(x) {}
};

B b=A();
