struct S1 { int s1 = 2; };
struct S2;
S2 *f(S1 *s) { return (S2*) s; }
struct T { int t = 1; };
struct S2 : T, S1 {};
int main() { S2 s2; return f(&s2)->t; }