
template <class T> 
class A { 
public: 
  A(){};
  ~A(){};
protected: 
  template<class X> friend class B; 
  void foo(){};
};

// when the A1 class is commented out
// the compile doesn't fail
class A1: public A<int> { 
public: 
  A1(){};
  ~A1(){};
};

template <class T> 
class B { 
public: 
  B(){};
  ~B(){};
  T myT;
  void bar() { myT.foo();};
}; 

int main() { 
  B<A<int> > b; 
  // this works only as long as the 
  // the entire definition of A1 is commented out
  // what I really wanted to do is 
  // B<A1> b; 
  // which was trying to reproduce a situation 
  // where somehow it complains that foo is protected
  // even though B is declared a friend in A... 
  // but that is another issue :-( 
  b.bar();
}
