struct  A { };
typedef A A_alias;

int main () {
  A ().A_alias::~A_alias (); // valid according to [class.dtor]p13
}