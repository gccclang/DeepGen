
#pragma interface

struct A
{
    virtual ~A();
};

template<typename T>
void f(const T& z)
{
    T x;
    T y(x);
    y = x;
}

int main()
{
    f(A());
}