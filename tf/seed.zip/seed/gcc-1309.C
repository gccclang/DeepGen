
int main() {
  int a = 0;
  a = a++;
  return a;
}