
template <int> void f() {}
int g() { f<1> (); }
template void f<1> ();