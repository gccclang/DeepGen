
#include <iostream>

int main() {
    try { throw "ABC"; }

    catch (char const (&)[4]) { std::cout << "Caught char const [4]" << std::endl; }
    catch (...)               { std::cout << "caught: ..." << std::endl; }
    }