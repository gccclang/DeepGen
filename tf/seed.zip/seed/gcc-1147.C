
#include <cstdlib>
#include <cstdio>
 
 
void exit( int a = 0 )
{
   std::puts( "dddddddd" );
   std::exit( a );
}
 
 
int main()
{
   exit( 1 );
}