#include    <iostream>

int main () {
    unsigned short us = ~0;
    unsigned int ui = 1;
    unsigned int res = ui + us;
    std::cerr << "res: " << res << ", ui: " << ui << ", us: 0x"
        << std::hex << us << "\n";
    res = 1;
    res = res + us;
    std::cerr << "res: " << res << ", ui: " << ui << ", us: 0x"
        << std::hex << us << "\n";
    return 0;
    }

