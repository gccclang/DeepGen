
typedef void (*Func) ();

struct A
{
  A (Func) {}
};

struct B
{
  static void staticfunc () {}
};

template <class T>
struct C
{
  C() : a (B::staticfunc) {}
  A a;
};

int main ()
{
  C<int> c;
  return 0;
}