
template<class T>
class Factory {
 public:
  static T* Create() { return new T; }
};

namespace {

class Type {
 private:
  friend class Factory<Type>;
  Type() {}
};

}

int main() {
  Type *c = Factory<Type>::Create();
}
