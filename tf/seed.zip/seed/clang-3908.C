
#include <iostream>
int main() {
  std::cout << 0.12345678 << "\n";
}