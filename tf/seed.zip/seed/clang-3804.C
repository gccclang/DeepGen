    int main(int argc, char** argv) {
      if (argc > 4);   // <-- Note semicolon!
      return 0;
    }