
class ctype_base
{
public:

    typedef unsigned short mask;
};

template <class _CharT>
class __ctype_abstract_base : public ctype_base
{
public:
};

template <class _CharT>
class ctype : public __ctype_abstract_base<_CharT>
{
public:
   typedef typename ctype::mask      mask;
};

int main()
{
   ctype<char> cc;
   return 0;
}
