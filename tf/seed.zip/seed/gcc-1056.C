
extern "C" const char*
foo()
{
  return "original";
}

const char*
test_foo()
{
  return foo();
}

extern "C" const char*
bar()
{
  return "original";
}

const char*
test_bar()
{
  return bar();
}

int main (int argc, char **argv)
{
  test_foo ();
  test_bar ();

  return 0;
}

