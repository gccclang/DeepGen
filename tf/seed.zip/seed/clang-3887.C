
#include <stdio.h>
class base {
  public:
    base(int * value);
  protected:
    int * value;
};

base::base(int * value)
 : value(value){}

class derived : public base {
  private:
    //int * value2;
  public:
    derived();
    void print() {printf("Child value is %p : %p\n",value,(int*)0);}
};

derived::derived()
 : base(value){}  //Self-assignment but no warning

int main()
{
  derived thisChild;
  thisChild.print();
}