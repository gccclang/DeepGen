
template<typename T>
class Target
{
public:
    virtual int Value() const
    {
        return 0;
    }
};

template<typename T>
struct Provider
{
    static Target<T> Instance;
};

template<typename T>
Target<T> Provider<T>::Instance;

int main()
{
    Target<int>* traits = &Provider<int>::Instance;
}