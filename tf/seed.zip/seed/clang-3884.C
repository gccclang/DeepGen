template<typename T, int dim>
struct point {};

template<typename T, int dim>
struct blubb {
  blubb(const point<T, dim> &x = point<T, dim>()) {}
};

int main(int argc, char * argv[]) {
  blubb<float, 3> x = blubb<float, 3>();
  return 0;
}
