#include <malloc.h>

namespace foo {
template<int x>
void bar(char *p) {
  *p = x;
}
}

int main() {
  char *buffer = (char*)malloc(42);
  free(buffer);
  foo::bar<42>(buffer);
}