
struct MyClass
{
   MyClass( const MyClass& );
   MyClass& operator=( const MyClass& );
   void volatile_member_func() volatile;
   static void static_func() {};
};

void
MyClass::volatile_member_func() volatile
{
   static_func();
}