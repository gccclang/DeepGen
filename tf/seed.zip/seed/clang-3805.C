
class X {
    int i;
    public:
    void m(int);         
    friend void f(X&);  
};
 
void X::m(int j) { i = j; }
 
void f(X& x) { x.i++; }
 
int main () 
{
    X x;
    x.m(3);
    f(x);
    return 0;
}
