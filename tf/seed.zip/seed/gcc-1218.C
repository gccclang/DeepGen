
extern "C" int printf (const char*, ...);

template <class T>
struct Cls
{
  Cls () { printf ("ctor %x\n", this); }
  ~Cls () { printf ("dtor %x\n", this); }
};

static Cls<int> xxx[1];

int main ()
{
  return 0;
}