#include <exception>

int main(void)
{
  try { throw std::exception(); }
  catch (std::exception& e) {}
  return 0;
}