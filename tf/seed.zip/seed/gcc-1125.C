
#include <map>

class A
{
public:
typedef std::map<unsigned char,int> TType;
        //A(const TType& x=TType()) // this works
        A( const std::map<unsigned char, int> & p_map = std::map<unsigned char, int>() ) // this doesn't
        {
        }
};

int main(void )
{
        A a;
        return 0;
}