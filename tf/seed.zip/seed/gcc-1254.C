
int count;

class C
{
public:
  int i;
  C() : i(1) { ++count;}
  C(const C &c) : i(c.i) { ++count;}
  ~C() { --count;}
};

int
f ()
{
  static const C &c = C();
  return c.i;
}

int
main ()
{
  int i = f ();
  return count < i;
}
