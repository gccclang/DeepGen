
#include <iostream>
 
typedef enum {
Enum1,
Enum2,
Enum3
} MyEnum;
 
template<typename X>
bool operator>(const X &inX1, const X &inX2)
{
return inX2 < inX1;
}
 
int main (int argc, const char * argv[]) {
 
MyEnum e1, e2;
 
if (e1 > e2)
std::cout << "its larger!\n" << std::endl;
else
std::cout << "its smaller!\n" << std::endl;
 
 
std::cout << "Done!\n" << std::endl;
return 0;
}