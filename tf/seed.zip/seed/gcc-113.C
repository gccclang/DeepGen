
template <typename foo>
void bar() {}
namespace { class C {};}
void (*FP)() = bar<C>;