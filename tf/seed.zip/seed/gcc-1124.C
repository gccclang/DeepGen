
class __attribute__( ( visibility ( "hidden" ) ) )  MyClass {
public:
  MyClass();

  int classmember;

};

MyClass::MyClass() {}

int main() {
  MyClass f;
  return 0;
}