
class A {
    class __attribute__((visibility("hidden"))) B {
    };
    B v;
};

int main (void) { A a; return (0); }