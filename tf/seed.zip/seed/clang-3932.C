
template<unsigned n> bool compare(unsigned k) { return k >= n; }
int main() { return compare<0>(42); }