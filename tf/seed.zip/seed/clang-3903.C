
#include <vector>

template <class T>
class TVector: public std::vector<T> {
public:
    TVector() {
    }
};

struct TData {
    TVector<int> A;
    TVector<int> B;
};

TData MakeEmptyData() {
    return {};
}

int main() {
    TData data = MakeEmptyData();
    return 0;
}