
extern "C" void abort (void);
void f(int) {}
static void f(char) { abort(); }
template<class T> void g(T t) { f(t); }
int main() { g('a'); }
