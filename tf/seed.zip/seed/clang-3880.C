

template <char const *p>
class A {
  char const *get_p() { return *p; }
};
template <int p>
class B {
  char const *get_p() { return p; }
};

