extern int N;
template <int &> struct S {};
void n (S<N>) {}