
#include <stdint.h>

/* Cannot use INT64_MIN or INT64_MAX as these
   are undefined when the g++ compiler is run. Even
   thought its clear it should be defined if __cplusplus
   is defined (see stdint.h). Which it seems to be at
   compiler initialization. Go figure?
*/
int main()
{

  int64_t   test;

  test = -(9223372036854775807)-1;
  test = 9223372036854775807;

  return 0;
}