#include <iostream>

typedef char char_T;

int main(int argc, const char_T * argv[])
{
        std::cout << "Hello Test World!" << std::endl;
        return 0;
}