
int a[4];
int *x, *y, *z;

void foo(void)
{
	x = &a[3] - 1;
	y = &a[1] + 1;
	z = 1 + &a[1];
}



void bar(int i)
{
	x = &a[i] - 1;
	y = &a[i] + 1;
	z = 1 + &a[i];
}

   want this.  Instead we get to see &a[i] and pointer offsetting
   by 4 and -4U.  */
