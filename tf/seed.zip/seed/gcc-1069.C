

#define THIRD

#ifdef THIRD
#define FIRST  i < 0 || 
#define ORIG int
#define CAST
#else

#define FIRST
#ifdef WORK_WORK_WORK
#define ORIG unsigned int
#define CAST
#else
#define ORIG int
#define CAST (unsigned)
#endif // WORK_WORK_WORK

#endif // THIRD

struct array
{
  const ORIG len;
  int *data;
};

extern void call (ORIG);

void doit (array *a)
{
  for (ORIG i = 0; i < a->len; ++i)
    {
      if (FIRST  CAST i >= CAST (a->len))
	throw 5;
      call (a->data[i]);
    }
}


