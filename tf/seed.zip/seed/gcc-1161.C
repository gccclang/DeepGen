

template <class C, typename T>
class DirectAttribute 
{
	public:
    	typedef T C::* MemberType;

    	DirectAttribute(MemberType m) : member(m) {}

    private:
    	MemberType member;
};

struct A
{
        double f;
};

template <class C> class ConcreteClass
{
};

template <> class ConcreteClass<A>
{
    public:
       ConcreteClass() : f1(&A::f) {}

    private:
    	DirectAttribute<A,double> f1;
};

int main()
{
	ConcreteClass<A> metaA;
}
