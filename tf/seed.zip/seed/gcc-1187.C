
template< int N >  class  C  {

public:
  enum { n = N };

  C()  { ; }

};  // C<n>


template< int n1, int n2 >
inline  C<n1+n2>
operator * ( C<n1> c1, C<n2> c2 )  { return  C<n1+n2>(); }

// ----------------------------------------------------------------------

template< class T, T (*G)() >  class S  {

public:
  inline     operator T  () const  { return (*G)(); }
  inline  T  operator () () const  { return (*G)(); }

};  // S<T,g>


template< class T, T (*G)()
        , class U, U (*H)() >
inline  C<int(T::n)+int(U::n)>
operator * ( S<T,G> s1 , S<U,H> s2 )  {

  static_cast<void>( s1(), s2() );
  return  C<int(T::n)+int(U::n)>();

}  // op*<>()

// ----------------------------------------------------------------------

C<1>  c1Gen()  {
  static  C<1> const  c1;
  return c1;
}

S< C<1>, &c1Gen >  s1;

// ----------------------------------------------------------------------

C<2>  c2Gen()  {
  static  C<2> const  c2( C<1>() * C<1>() );
  return c2;
}

S< C<2>, &c2Gen >  s2;

// ----------------------------------------------------------------------

C<3>  c3Gen()  {
  static  C<3> const  c3( C<1>() * C<2>() );
  return c3;
}

S< C<3>, &c3Gen >  s3;

// ----------------------------------------------------------------------



int  main()  {

  C<1> c1;  C<2> c2;  c1 * c2;
  C<3> c3( s3 );

  // GCC 2.95.2:  why do you report that there is "no match" for
  // the following right-hand side operator *() ?
  c3 = s1 * s2;

  return 0;

}  // main()
