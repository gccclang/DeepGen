
int main(void)
{
static char *t = "hello";
return(0);
}
