
struct Base {                                                                       
        virtual Base *copy(void) = 0;                                               
        virtual ~Base() { }                                                         
};  
                                                                                
                                                                               
    template <typename T>
void make(void) {                                                                   
        struct Test : public Base {                                                 
                Base *copy(void) {                                                  
                        return new Test(*this);                                     
                }                                                                   
        };                                                                          
        new Test();                                                                 
}                                                                                   
                                                                                    
int main(void) {                                                                    
        make<double>();                                                             
        return 0;                                                                   
}