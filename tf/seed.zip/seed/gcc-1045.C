
struct basic_string { basic_string(const basic_string&); };
basic_string operator+(const basic_string& lhs, char);
struct TrieNode { const TrieNode* nextSibling() const; };
void dumpNode(const TrieNode* node, basic_string start)
{
  dumpNode(node, start + 'a');
}