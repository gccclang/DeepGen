
namespace X {  template <class T> void f () {};   };
template void X::f<int> ();