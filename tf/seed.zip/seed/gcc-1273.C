
template<typename T>
class has_subscript_operator
{
private:
  template <int> struct helper {};
  template <class U> static int foo( helper<sizeof( &U::operator[] )> * );
public:
  int value() { return 0; };
};
  
int main() {
//  return has_subscript_operator<int>::value;
  return has_subscript_operator<int>().value();
}