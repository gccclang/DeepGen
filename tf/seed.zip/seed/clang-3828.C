
extern "C" char memmove();

int main() {
  return memmove();
}