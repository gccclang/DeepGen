struct A { int x; };

struct B : public A {
	virtual int foo() { return x; }
};

int main() {
	B *b = new B();
        b->x = 42;
	A *a = b;
	B *ptr = reinterpret_cast<B *>(a); // bad idea!
	return ptr->foo();
}
