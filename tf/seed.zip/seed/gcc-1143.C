
class X
{
   public:
          X()
          {
          }
   private:
          X( const X& );
          X& operator=( const X& );
};

void f( const X& )
{
}

int
main()
{
   f( X() );
   return 0;
}
