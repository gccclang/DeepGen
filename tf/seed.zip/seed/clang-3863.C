
#include <iostream>
int main() {
  std::cout << "hello" << std::endl;
}