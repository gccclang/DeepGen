struct Foo {
  static int count() __attribute__((constructor)) {
    static int cnt = 0;
    return ++cnt;
  }
};

int main() {
  return Foo::count();
}