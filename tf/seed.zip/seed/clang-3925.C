enum My_Enum
{
    A, B
};

const My_Enum Get_A()
{
    return A;
}

int main( int argc, char **argv )
{
    const My_Enum result = true ? Get_A() : B;

    return 0;
}