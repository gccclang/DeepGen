
class foo
  {
  void f(int *p)
    {
#pragma omp parallel for
    for (int i=0; i<1000; ++i)
      p[i]=0;
    }
  };