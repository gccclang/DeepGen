
#include <stdio.h>
#include <signal.h>
void signal_handler(int signo) {
	fprintf(stderr,"signaled\n");
	throw 1;
}

int main()
{	signal(SIGSEGV,signal_handler);

	try {
		printf((char*)9); //<---(A)
	}
	catch(...) {
		fprintf(stderr,"exception caught");
	}
}