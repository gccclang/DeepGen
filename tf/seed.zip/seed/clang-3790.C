  namespace M { struct i {}; }
  namespace N { static int i = 1; }
  using N::i;
  using M::i;
  int main() { sizeof (i); }