
#include <vector>
template <class T>
struct Observer {};
template<class T>
struct Observable
{
  void notify(int event);
  std::vector<Observer<T> *> observers_m;
};
template <class T>
struct CompressibleBlock
{
  enum Notifier { notifyUncompress = 1 };
  void uncompressUnlocked()
  {
     Observable<T*>::notify(notifyUncompress);
  }
};