
struct TERM {
    unsigned data;

    TERM() { data = 0; }
};

struct C {
  TERM *t;

  C() {
    t = new TERM[3];
  }

  C( TERM *t2 ) {
    if( t2 ) {
      t = new TERM[3];
      t[0]=t2[0];
    }
  }
};

extern TERM *aTerm;

int main() {
   C x(aTerm);
   C y=x;
}
