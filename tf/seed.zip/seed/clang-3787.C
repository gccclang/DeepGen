
struct C {
  ~C();
};
extern bool b;
void fun1() { b && (C(), 1); }
bool fun2() { return (C(), b) && 0; }
