
extern "C" int printf(const char *...);

struct s7 {
  virtual void fun10(char *t) { }
} a7;
struct s20 {
  virtual void fun100(char *t) { }
} a20;
struct s21: s7, s20 {
  virtual void fun100(char *t) { }
} a21;
struct s23: virtual s21 {
} a23;
int main() {
}