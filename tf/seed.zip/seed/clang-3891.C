#include <typeinfo>

template<typename T> void foo() {};
         
int main() {
    typeid(foo<int>);
}