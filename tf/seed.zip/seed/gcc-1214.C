template<typename T_1,typename T_2>
class T:
public T_1
{
 public:

  template<typename W_1,typename W_2>
  operator T<W_1,W_2>(void)const
  {   
    //converts any T to any other type of T
    //not implemented, never mind

    T<W_1,W_2> result;
    return result;
  };
  
};


class R
{
public:

  operator class P(void)const;
  operator class Q(void)const;
  operator class Z(void)const;

};


class S
{

};


class Derived_T:
public T<R,S>
{

};