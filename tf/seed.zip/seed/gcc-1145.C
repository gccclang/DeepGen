
extern "C" int printf(const char *, ...);
class MSBinaryVector {
public:
    MSBinaryVector (unsigned int, unsigned char =0)
    {
    }
};
MSBinaryVector operator& (const unsigned char, const MSBinaryVector
                          &){
    printf("not built-in\n");
    return 0;
}
typedef unsigned char __iostate;
enum io_state { eofbit };
int main() {
    __iostate state;
    return state & eofbit;
}
