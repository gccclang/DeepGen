
#include <unistd.h>

namespace foo {
typedef long long offset_t;
}

using namespace std;
using namespace foo;

int main() {
    offset_t fpos;
}