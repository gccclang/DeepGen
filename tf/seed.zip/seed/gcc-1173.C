
#include <iostream>

class Condition
{
  public:
    void EssaiCond( const int );
};

void Condition::EssaiCond( const int cond )
{
    if(cond)
        {
            std::cout << "true\n";
        }
    else
        {
            std::cout << "false\n";
        }
}

int main()
{
    Condition essai;
    essai.EssaiCond(true);
    essai.EssaiCond(false);
    return(0);
}
