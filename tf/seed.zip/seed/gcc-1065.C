
void
foo ()
{
  try { foo (); }
  catch (...) { __builtin_abort (); }
}
