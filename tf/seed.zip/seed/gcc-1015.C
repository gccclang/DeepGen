

struct A
{
    void f();
    template <class T> static void g();
};

struct B {};

void h( void (*)() );

void A::f()
{
    h(&g<void>);
}