
namespace B {
  namespace {
    class D {
      public:
        int i;
    };
  }
}

B::D x;

int main() {
}