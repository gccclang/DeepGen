struct interface { };
struct base1_if : virtual interface { };
struct base2_if : virtual interface { };
struct base_if : base1_if, base2_if { };

struct derived : base_if {
    derived()
        : base_if()
    { }
};

int main() { derived d; }