
struct font_params {
  int x_height;
};
typedef int font_params::*param_t;
static struct {
  const char *name;
  param_t par;
} param_table[] = {
  { "x-height", &font_params::x_height },
};
int main(int argc, char **argv)
{
}