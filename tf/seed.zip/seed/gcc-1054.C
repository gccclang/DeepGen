
typedef int int32;
typedef int32 real_const_t;

class real
{
private:
  int32 value;

public:
  real(void) {}
  real(const real & z_a) {value = z_a.value;}
  friend real operator+ (real, real);
};

inline real operator+ (real z_a, real z_b)
{
  real temp;
  temp.value = (z_a.value) + (z_b.value);
  return temp;
}

real r,r1,r2,r3;

void test (void)
{
       r = r1 + r2 + r3;
}