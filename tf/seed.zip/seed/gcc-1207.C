
template<class T> struct StaticClass
{
        static void ret() {}
};

template<class T>
void func(void function()) {}

template<class T> struct Test
{
        void doIt()
        {
                func<T>(StaticClass<Test<double> >::ret);
        }
};
