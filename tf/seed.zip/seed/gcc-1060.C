
#include <stdio.h>

void a() {
        printf("a\n");
}


#include <stdio.h>

extern void c();

void bc() {
  printf("b\n");
  c();
}


#include <stdio.h>

class F {
  public:
  F() {
        printf("F()\n");
  }
};

static F f;
