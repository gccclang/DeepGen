
#include <stdio.h>
#include <string.h>
int main()
{
        char * strArray[2];
        printf("Enter 1:");
        scanf("%s",strArray[0]);
        printf("Enter 2:");
        scanf("%s",strArray[1]);
}
