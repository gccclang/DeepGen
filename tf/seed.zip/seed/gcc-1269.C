struct s
{
    int i1, i2;
};

const s c1 = { 1, 2 };
const s ca1[] = { { 1, 2} };
const s c2 = c1;
const s ca2[] = { c1 };

int main(void)
{
    return 0;
}