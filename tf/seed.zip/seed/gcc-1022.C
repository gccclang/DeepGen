
class Vector {
public:
  Vector() {}
  Vector(float x, float y, float z) { coords[0]=x; coords[1]=y; coords[2]=z; }
private:
  float coords[3];
};

class Model {
public:
  Model() {}
  Model(const Vector &m, const Vector &n) { M=m; N=n; }
private:
  Vector M, N;
};

int main(int argc, char **argv) {
  float v1[3], v2[3];

  Model m(Vector(v1[0],v1[1],v1[2]), Vector(v2[0],v2[1],v2[2]));

  return 0;
}
