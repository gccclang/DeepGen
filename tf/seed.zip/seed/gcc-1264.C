
struct T
{
  virtual void m () { }
};
int
main ()
{
  bool fn (T);
  return 0;
}
