
double const d = 4.3;
int const c = (int)d;
int a[c];