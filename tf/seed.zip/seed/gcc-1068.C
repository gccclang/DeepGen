
template <typename T, T defaultValue = T()> 
struct A{  
  A() : t(defaultValue) {}
  T t;
};

template <typename T> void fct(A<T> a){}

struct B{
  void hello(){ fct( a );}
  A<char> a;  
};