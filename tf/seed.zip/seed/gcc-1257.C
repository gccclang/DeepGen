
struct A { A (bool); };

static void
foo (const char *x)
{
  new A (x);
}

void
bar ()
{
  foo ("foo");
  foo ("bar");
}
