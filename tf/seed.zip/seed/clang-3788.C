  template<typename T>
  struct A {
    friend void f(A *) { }
  };

  int main() {
    f((A<int>*)0);
  }