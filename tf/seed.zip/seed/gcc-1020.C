
int a[1] = { 0 };

void
foo ()
{
  a[({ 0; })] %= 5;
}
