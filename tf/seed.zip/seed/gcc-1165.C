
class bbb {
public:
	void test();
};

template<typename T> class ttt {
	T*p;
public:
	void test() { p->test(); }
};

class ddd;

class ccc {
	ttt<ddd> m;
public:
	void test() { m.test(); }
};

void test(ccc&r) {
	r.test();
}

class ddd : public bbb {};
