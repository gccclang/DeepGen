
int * f( int a)
{
	return &a;
}

int * g()
{
	int b = 0;

	return &b;
}

/*
then

[dcb@localhost src]$ ~/gnu/gcc333pre2/results/bin/g++ -c -g -O2 -Wall -ansi
-pedantic addrLocal.cc
addrLocal.cc: In function `int* g()':
addrLocal.cc:9: warning: address of local variable `b' returned
[dcb@localhost src]$

Note only one warning message.  
G++ 333 pre release version 2 doesn't find the problem in function f.  
G++ 332 also doesn't find the problem.

Here is Intel C++ doing what I want.

[dcb@localhost src]$ icc -c addrLocal.cc
addrLocal.cc(6): warning #1251: returning pointer to local variable
        return &a;
               ^

addrLocal.cc(13): warning #1251: returning pointer to local variable
        return &b;
               ^

This bug report boiled down from real code in Fedora Core 1.

*/
