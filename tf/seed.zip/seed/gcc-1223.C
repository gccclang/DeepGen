struct TT1 {
    static int      v1;
    static int      v2;
    };
int         TT1::v1;
int         TT1::v2 = 3;
template<typename U> struct TT2 {
    static int      v1;
    static int      v2;
    };
template<> int          TT2<bool>::v1;
template<> int          TT2<bool>::v2 = 3;

int main() {
    TT1         v;
    v.v1 = 0;
    v.v2 = 0;
    TT2<bool>   vt;
    vt.v1 = 0;
    vt.v2 = 0;
    }