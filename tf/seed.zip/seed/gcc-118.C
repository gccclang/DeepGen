int foo() __attribute__((noreturn));
int bar() { return foo(); }
