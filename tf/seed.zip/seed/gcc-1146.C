
struct A {int* next; };
struct B {int* next; };
struct C : public A, public B { using A::next; };
void foo(C* c) { c->next = 0; }