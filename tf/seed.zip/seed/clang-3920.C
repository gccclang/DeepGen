
extern "C" char pow ();
int main ()
{
  return pow ();
}