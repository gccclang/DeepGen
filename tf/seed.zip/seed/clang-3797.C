
#include <stdio.h>

class C {
 public:
  void foo() { printf("%d\n", a); }

 private:
  int a;
};

int main() {
  C c;
  c.foo();
}