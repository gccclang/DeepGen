
void foo()  throw ()
{
  __PRETTY_FUNCTION__; 
}