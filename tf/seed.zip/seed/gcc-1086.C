

struct foo {
  static int bar(...);
  static int const RET = sizeof(bar(0));
};

int main() 
{ return 0; }