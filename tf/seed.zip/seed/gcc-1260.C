
class A {
    virtual int x() = 0;
};

class B:public A {
    int x();
};

int B::x() {
    return 0;
}
