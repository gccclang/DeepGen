


static int a;

struct A
{
  virtual ~A () { a++; }
};

struct B : public A
{
  virtual ~B () { a++; }
};

void test ()
{
  B *b = new B;
  b->A::~A ();
} 

int main ()
{
  test  ();
  if (a != 1)
    __builtin_abort ();
}
