
template<typename T> class xcomplex
  {
  public:
    T re, im;

    xcomplex (const T &re_, const T &im_)
      : re(re_), im(im_) {}
    template<typename U> xcomplex (const xcomplex<U> &orig)
      : re(orig.re), im(orig.im) {}
    xcomplex operator* (const T &fact) const
      { return xcomplex (re*fact,im*fact); }
  };

void foo (xcomplex<double> *a, double *b, xcomplex<double> *c)
  {
  for (int m=0; m<1000; ++m)
    c[m]=a[m]*b[m];
  }
