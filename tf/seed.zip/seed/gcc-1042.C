
void bar (int *p)
    {
#pragma omp parallel for
    for (int m=0; m<1000; ++m)
      {
      switch(p[m])
        {
        case 1:
          p[m]=2;
          break;
        }
      }
    }