

// -- begin tu.cpp --
template< class T >
	struct C
	{
		static T returnaT();
		enum { itsSize = sizeof C::returnaT() };
	};

int
main(int argc, char* argv[])
{
	long aSize = C<double>::itsSize;
	return 0;
}
// -- end tu.cpp -
