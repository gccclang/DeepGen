
#include <stddef.h>

template <class T>
class A {
 public:
  void f(T t = NULL) {  // doesn't warn
    t_ = NULL;  // warns
  }
  T t_;
};

int main() {
  A<int> a;
  a.f();
}