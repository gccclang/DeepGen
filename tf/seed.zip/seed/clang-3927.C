#include <string>

int main()
{
 void (std::string::*f)() = &std::string::clear;
}