#include <stdio.h>

typedef struct __attribute__ ((packed, aligned(4)))
{
    short a;
    short b;
    int     c;
} A;

int main() {
    A s;
    s.c = 0;
    int* ptr = &s.c;
    printf("%d", *ptr);
    return 0;
}