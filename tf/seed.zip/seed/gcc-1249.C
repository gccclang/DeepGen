
volatile int a;

void
foo ()
{
  ({
     a;
   });
}
