
struct MdatResource {
const char *mdatAlloc;
} const *_resource;
