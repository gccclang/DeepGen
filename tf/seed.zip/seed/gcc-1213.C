/*************a.C********/
struct A        { virtual void f() {}; };
struct B        {int b;};
struct C : A, B { virtual void f() {}; int c;};
struct D : C    {int d;};
struct E : C    {int e;};
struct F : protected D, E  {int f;};
struct H : virtual F {int h;};
struct I : H  {int i;};
struct J : H  {int j;};
struct K : I, J { virtual void f() {}; int k; };
struct M : K  {int m;};
struct N : M  {int n;};
struct O : M  {int o;};
struct P : N, O { virtual void f() {}; int p;};

int main() {

    P obj;
A* a1 = (D*)&obj;
    try {
    //A* a1 = (D*)&obj;
        H* hp = dynamic_cast<H*>(a1);
    }catch (...) {
        return 1;
    };

    return 0;
}