
#include <assert.h>

struct Y {
  Y () : _y(0) {}
  int _y;
  int y () const  { return _y; }

};

struct X {
  X () {}

  Y _y;

  inline int x() const { return 0; }
  inline Y y() const { return _y; }

};


int main()
{
  X x;
  assert (x.y().y()==0);

  assert ( ((x.x()==0) && (x.y().y()==0)) );
  return 0;
}