
#include <vector>
#include <iostream>

struct A {
  std::vector<double> v, w;
  A();    
};

A::A() : v(2), w(2){
  std::cerr << "foo" << std::endl;

  for (int i = 0; i < 2; i++){
    for (int j = i+1; j < 2; j++){
      w[i] -= v[i];
      w[j] -= v[j];
    }
  }
  
}

int main (){
  A a;
  return 0;
}
