
struct stat { };

int stat(struct stat*);

namespace posix {
  int stat(struct stat&);
}

int posix::stat(struct stat&);