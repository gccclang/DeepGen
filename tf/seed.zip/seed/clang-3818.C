
struct s0 {
  virtual void fun9(char *t) { }
} a0;
struct s1 {
  virtual void fun9(char *t) { }
} a1;
struct s2: s1 {
} a2;
struct s3: s2, s0 {
  virtual void fun9(char *t) { }
} a3;
struct s8: s3 {
  virtual void fun9(char *t) { }
} a8;
int main() {
}