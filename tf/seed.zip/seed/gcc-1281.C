
#include <iostream>
#include <cstddef>

class xxx {
    friend int main();
    void *q;
  public:
    void *r;
};

int main() {
    std::cout << "offset of xxx::q is " << offsetof( xxx, q ) << "\n";
    std::cout << "offset of xxx::r is " << offsetof( xxx, r ) << "\n";
    return 0;
}