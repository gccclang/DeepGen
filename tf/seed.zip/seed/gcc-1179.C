
#include <stdarg.h>

struct S { va_list err_args; };

void *
foo ()
{
  return new S ();
}
