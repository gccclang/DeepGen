template< int X, int Y, int (*array_ptr)[Y] > class A {};
int array[5];

template< int X > class A<X,5,&array> { };

int main()
{
    A<6,5,&array> z1;    
}
