
struct foo {
   int a;
   int b;
};

class Foobar : public foo {
public:
    Foobar() { a = 1; b = 2; };
    virtual ~Foobar() {};
};

Foobar obj;
const Foobar* objPtr = &obj;
foo* f = (foo*)objPtr;