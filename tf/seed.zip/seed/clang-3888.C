
template< typename S >
    struct C
{
    template< int >
        void F( void )
    {
    }
};

template< typename S >
    struct D
{
    typedef C< int > A;
};

typedef D< int >::A A;

template<>
template<>
    void A::F< 0 >( void )
{
}

int main( void )
{
    return 0;
}
