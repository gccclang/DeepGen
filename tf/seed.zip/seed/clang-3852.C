#include <iostream>
  
bool f1() {return false;}
bool f2() {return true;}

int main() {

  if (f1()) {
    std::cout << "1" << std::endl;
  } else if (f2()) {
    std::cout << "2" << std::endl;
  } else {
    std::cout << "3" << std::endl;
  }

  return 0;
}