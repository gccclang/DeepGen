
class Base {};

class Derived : public Base {};

class From {
 public:
 operator Derived() const { return Derived(); }
};

template <typename T>
class BaseT {};

template <typename T>
class DerivedT : public BaseT<T> {};

template <typename T>
class FromT {
 public:
 operator DerivedT<T>() const { return DerivedT<T>(); }
};

int main() {
 From f;
 Base b(f);  // This works with GCC and Clang.

 FromT<int> ft;
 BaseT<int> bt(ft);  // This works with GCC, but not Clang.
}