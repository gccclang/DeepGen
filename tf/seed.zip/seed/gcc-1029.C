
namespace NS
{
  inline int right() {}
}
int foo (int (*pf) ()) { return pf(); }

int main()
{
  return foo (NS::right);
}