
struct A {
  int const static a0 = 0;
  int const static a1 = 1;
};

int
main ( int argc, char ** ) {
  int a = argc ? A::a0 : A::a1;
  return ( a );
}
