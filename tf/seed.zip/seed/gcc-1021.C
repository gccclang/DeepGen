
#include <utility>  // defines pair template
#include <iostream>
using namespace std;

typedef pair<int, int> ijpair;

class foo {
public:
	// this does not work,...
	// foo( pair < int, int > ij = pair < int, int > ( 0, 0 ) ) : indices ( ij ) { }
	// ...but this does:
	foo( pair<int,int> ij = ijpair(0,0) ) : indices(ij) { }
	void displayme() { cout << indices.first << ',' << indices.second << endl; }
private:
	pair<int, int> indices;
};

int pairsum(pair<int,int> ij = pair<int,int>(0,0))
{
	return ij.first+ij.second;
}

int main(void)
{
	foo f1 = foo(pair<int, int>(42,7));
	foo f2 = foo();
	f1.displayme();
	f2.displayme();
	cout << pairsum() << endl;
	return 0;
}