
bool bar(int i, unsigned int u)
{
    return i < u;
}

template<typename T> bool baz(T i, unsigned int u)
{
    return i < u;
}

void foo()
{
    bar(-3,5);
    baz(-3,5);
}