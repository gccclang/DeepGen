
namespace Passenger {
namespace Json {
class Value {};
} // namespace Json
namespace ConfigKit {
class Translator {};
} // namespace ConfigKit
namespace LoggingKit {
void initialize(const Json::Value & = Json::Value(),
                const ConfigKit::Translator & = ConfigKit::Translator());
void init_module() { initialize(); }
} // namespace LoggingKit
} // namespace Passenger

