int main()
{
    try
    {
        throw 0;
    }
    catch(int k)
    {
    }

    return 0;
}