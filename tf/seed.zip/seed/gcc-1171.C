
template<class T>
class A
{
public:
   static const unsigned int n = 1;

   void foo ()
   {
      int i = n;
   }
};

extern template class A<int>;

int main ()
{
   A<int> a;
   a.foo ();
}