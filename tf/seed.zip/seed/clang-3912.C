#include <stdio.h>

struct S {
  char tmp[0];
};

struct T {
  struct S v01;
  struct S v02;
};

int main(void) {
  printf("%lu\n", sizeof(struct S));
  printf("%lu\n", sizeof(struct T));
  return 0;
}