
 template<class T> struct Y { typedef T X; };

 // Primary base
 template<class T, class U> struct Base {};

 // partial specializations
 template<class T> struct Base<T, typename T::X> {};

 template<class T> struct Base<typename T::X, T> {};

 template<class T, class U> struct Derived : Base <T, U> {};

 struct A {};

 template<class T> struct Derived<A, T> : Base< Y<T>, Y<T> > {};

 int main()
 {
     Derived<A, int> d;
 }