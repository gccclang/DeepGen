
extern "C"
void fork () // { dg-warning "conflicts with built-in declaration" }
__attribute__ ((__nothrow__));

void foo () throw ()
{
  fork ();
}

