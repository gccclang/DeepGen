

struct B
{
  B() {}
  B(B const&) {} // works if this line is commented out

  template<typename T>
  B(T const& a) { a = a + a; }
};

struct D : B {};

int main()
{
  D d;
  D d2(d); // calls templated base constructor - bad
  return 0;
}