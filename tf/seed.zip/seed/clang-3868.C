
static const bool False = false;

struct A {
  ~A();
  operator bool();
};
void Bar();

void Foo() {
  if (False && A()) {
    Bar(); // expected-no-diagnostics
  }
}
