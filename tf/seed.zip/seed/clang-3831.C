#include <string>
#include <sstream>
 
int main() {
  std::string str = "Hello, world";
  std::istringstream in(str);
  std::string word;
  in >> word;
  int pos = in.tellg();
}