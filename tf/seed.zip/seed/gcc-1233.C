class OtherClass;

class MyClass
{
public:
	const OtherClass* GetOther() const { return ( m_other_p ); }

protected:
	OtherClass* GetOther() { return ( m_other_p ); }

	OtherClass *m_other_p;

	friend class FriendClass;
};