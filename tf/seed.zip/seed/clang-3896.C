struct my_id {
  my_id() : v_(0) {}
  int v_;
};
template <typename T> struct Foo {
  static my_id id;
};
template <typename T> my_id Foo<T>::id;
int main() { Foo<char>::id.v_++; }