
struct Base {
  virtual ~Base() { }
  virtual Base *clone(void) = 0;
};

template<typename T>
struct Derived : public Base {
  Base *clone(void)
  {
    return (new Derived(*this));
  }
};

int
main(void)
{
  Derived<int> d;
  Base *b = d.clone();

  delete b;
}