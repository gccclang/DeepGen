
 extern "C" typedef void foo ();