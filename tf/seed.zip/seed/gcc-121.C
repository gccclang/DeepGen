
 template<int N> struct alpha {};

 template<typename T>
   struct tau {
       static const int D = T::some_CT_int_member;
       typedef alpha<D> beta;
       void find(beta&) const;
   };

 template<typename T> void tau<T>::find(beta& x) const {}
