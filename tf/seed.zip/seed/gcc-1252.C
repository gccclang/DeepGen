

#include <limits>
#include <limits.h>

namespace boost {
template<class T>
class integer_traits : public std::numeric_limits<T>
{
public:
  static const bool is_integral = false;
};

namespace detail {
template<class T, T min_val, T max_val>
class integer_traits_base
{
public:
  static const bool is_integral = true;
  static const T const_min = min_val;
  static const T const_max = max_val;
};
} // namespace detail

template<>
class integer_traits<long long>
  : public std::numeric_limits<long long>,
    public detail::integer_traits_base<long long, LONG_LONG_MIN, LONG_LONG_MAX>
{ };

} // namespace boost