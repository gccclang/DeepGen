
#include <string>
 
int
main()
{
  std::string x;
  x.erase(x.begin(), x.end());
}