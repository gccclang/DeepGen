struct B {
  B() : i(0) {}

private:
  int i;
};

struct C : B {
  C() {}  // Warning here about not initiaizing base class would be nice.
};

int main() {
  C *c = new C;
  return 0;
}