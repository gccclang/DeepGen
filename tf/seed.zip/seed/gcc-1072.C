

#include <iostream>

template <class T> class A { 
public:
  static void foo () { std::cout << "Not volatile"; }
};

template <class T> class A<volatile T> {
public:
  static void foo () { std::cout << "Volatile"; }
};

template <class T>
void x(T& t) {
  A<T>::foo();
  // T here should be a plain function type int()() (not a pointer, not a ref)

  // The compiler (3.20) picks the specializatoin for A<volatile T> ???
}

int bar() {};

int main() {
  x(bar);
};

