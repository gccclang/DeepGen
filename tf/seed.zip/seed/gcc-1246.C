
enum state_e
{
    STATE_0 = 0,
    STATE_1 = 1,
};
                                                                                
struct packed_state_t
{
    state_e state : 8;
} __attribute__ ((packed));
                                                                                
class foo_c
{
 public:
                                                                                
    void set_state (unsigned p, state_e s);
};
                                                                                
class bar_c
{
 public:
                                                                                
  struct
  {
    unsigned a;
    unsigned b;
  } r;
                                                                                
  __inline__ unsigned get_a () const { return this->r.a; }
                                                                                
  __inline__ unsigned get_b () const { return this->r.b; }
                                                                                
  __inline__ unsigned
  get_u (unsigned a) const
    {
      return a + this->get_b ();
    }
                                                                                
  packed_state_t* state;
                                                                                
  foo_c* foo_if;
                                                                                
  void set_state (unsigned p, state_e s);
};
                                                                                
enum state_params_e
{
    STATE_LOG_CHUNK_SZ = 7,
    STATE_CHUNK_SZ = 1 << STATE_LOG_CHUNK_SZ
};
static __inline__ unsigned
get_state_index (unsigned a)
{
    return a >> STATE_LOG_CHUNK_SZ;
}
                                                                                
void
bar_c::set_state (unsigned p, state_e s)
{
    unsigned u = this->get_u (p);
    if (u < this->get_a ())
    {
        this->state [get_state_index (u)].state = s;
        return;
    }
                                                                                
    this->foo_if->set_state (p, s);
}