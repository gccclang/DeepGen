
template<typename>
struct A {
  // if we change the typedef to "short", clang
  // should complain.
  typedef int foo; 
  operator int() {
    return 0;
  }
};

template<typename>
struct B {
  // this is not found, because B<T> is a dependent base.
  typedef short foo;
};

// makes sure applicable name-lookup
// on definition context classifies "foo"
// as a type so it matches the syntax.
struct TypeNameSugar {
  typedef int foo;
};

template<typename T>
struct C : A<T>, B<T>, TypeNameSugar {
  void c() {
    A<T> *p = this;

    // dependent "p" makes "foo" a dependent name.
    p->operator foo();
  }
};

int main() {
  C<void>().c();
}
