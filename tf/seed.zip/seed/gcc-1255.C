
extern int f( int );

void g()
{
	int i;

	f( i);
}
