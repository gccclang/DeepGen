
template<typename T>
struct X {
    X (int);
};

template<typename T>
X<T>::X (int i __attribute__ (())) {}