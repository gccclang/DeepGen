
#include<iostream>

using namespace std;

class A {
private:
        virtual void abc()
        {
                cout << "Base Class called\n";
        }
};

class B : public A {
public:
        void abc()
        {
                cout << "Derived Class called\n";
        }
};

int main()
{
        A a;
        B *b = static_cast<B *>(&a);
        b->abc();
}