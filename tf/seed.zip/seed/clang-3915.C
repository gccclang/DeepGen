
struct A { }; struct B : A { void f(int); void f(); }; int main() { static_cast<void (A::*)()>(&B::f); }
