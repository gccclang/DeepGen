enum E {
   e = 3,
};

int main() {
  bool var1 = e; // truncation from 'E' to 'bool'
  bool var2 = 3; // truncation from 'int' to 'bool'
}
