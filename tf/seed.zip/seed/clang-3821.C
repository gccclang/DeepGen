
#include <stdio.h>

class A {
 public:
  A() {}
  ~A() {}
};

int main() {
  printf("before ctor\n");
  {
    volatile A a;
    printf("before dtor\n");
  }
  printf("after  dtor\n");
}