
struct B {
  B() : main(1), sub(1) {}
  struct {
    int main;
    int sub;
  };
} A;

int main()
{
  return 0;
}