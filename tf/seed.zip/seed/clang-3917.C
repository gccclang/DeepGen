template <class T>
struct A
{
};

template<class T>
class B
{
    A<T> a_;
public:
    void destroy();
};

template<class T>
void
B<T>::destroy()
{
    a_.~A<T>();
}

int main()
{
}