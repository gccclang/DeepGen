
namespace A {
  typedef class C C;
  typedef int T;
  class C { T i; };
}