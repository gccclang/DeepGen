
#include <stdio.h>

enum E { e = 0x10000 };

int main ()
{
    int a [] = {
        E (0x1), E (0x10), E (0x100), E (0x1000), E (0x10000),
        E (0x100000), E (0x1000000), E (0x10000000)
    };

    for (int i = 0; i != sizeof a / sizeof *a; ++i) {
        int j = E (1 << (i * 4));
        printf ("1 << %d: %#x == %#x\n", i * 4, a [i], j);
    }
}