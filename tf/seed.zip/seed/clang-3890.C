
struct A
{
  ~A() { }
};

template<typename T>
struct B {
  struct C : A {};
  void f()
  {
    C c = C();
  }
};

int main() { return 0; }