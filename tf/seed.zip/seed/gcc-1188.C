
#include <string>
#include <iostream>

std::string repeat(const std::string& p_str, unsigned int p_count)
{
    std::string result;
    for (unsigned int i=0;i<p_count;++i)
        result+=p_str;
    return result;
}

int main(void)
{
        std::cout << repeat("gnu", 20) << std::endl;

        return 0;
}