
#include <iostream>
using namespace std;

int f(int i) 
{
  int j = (j < 0) ? -i : i; // shouldn't that generate a warning that j is used uninitialized
  return j;
}

int main()
{
  int h = 3;
  cout << h << " " << f(h) << "\n";
  h = -3;
  cout << h << " " << f(h) << "\n";
  return 0;
}