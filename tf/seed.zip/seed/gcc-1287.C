
template <int MSB, int LSB>
struct	Data {
    Data();
    operator unsigned ();
};

template<int EXTMSB, int EXTLSB>
struct Funct : public Data<EXTMSB - EXTLSB, 0> {
    template<int MSB, int LSB>
    Funct(const Data<MSB,LSB> &src); 
};

Data<88,0>	abc;
int main() {
    unsigned x;
    //x = unsigned(Funct<20,20>(abc)) << 1;	   // works
    x = (unsigned(Funct<20,20>(abc)) << 1);	   // does not work
    // x = ((unsigned)Funct<20,20>(abc) << 1) ;	   // works
    return 0;
}