#include <iostream>

class A;
void f(const A& a);

class A {

    public:
        explicit A():i(5) {}

        friend void f( const A& a) //Consider the friend
        {  std::cout << a.i << std::endl; } 

    private:
        int i;

};

int main(int argc, char **argv) {

    A a;
    f(a);
}