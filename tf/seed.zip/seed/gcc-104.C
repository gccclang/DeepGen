
class Copy
{
public:
	Copy() : m_value(0), m_flag(false) {}
	Copy& operator=(const Copy& source)
	{
		m_value = source.m_value;
		return *this;
	}
	
private:
	int m_value;
	bool m_flag;
};

int main()
{
	Copy instance;
	Copy another;
	another = instance;
	
	return 0;
}