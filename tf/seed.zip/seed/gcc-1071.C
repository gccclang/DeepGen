
typedef void ( * F )( );

template< class T >
struct A
{
	static F sF;
};

struct B
{
	template< class T >
	static void f( );
};

template< class T >
F A< T >::sF = B::f< T >;

F gF = A< int >::sF;
