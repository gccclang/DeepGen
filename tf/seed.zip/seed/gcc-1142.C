
int var;
