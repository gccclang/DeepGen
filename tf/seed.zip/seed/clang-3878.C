
#include <map>

struct Base {
  virtual ~Base() { }
};

struct Derived : public Base { };

struct Map {
 std::map<int, Base *> members_;

 template<typename T>
 void get(int key, T **tp) const
 {
  std::map<int, Base *>::const_iterator it;

  it = members_.find(key);
  *tp = dynamic_cast<T *>(it->second);
 }
};

int
main(void)
{
  Map m;
  Derived *b;
  m.get(2, &b);
}