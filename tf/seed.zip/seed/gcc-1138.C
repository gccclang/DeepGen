
#include <string> 
 
struct AAA { 
        AAA(const char*) 
        {} 
}; 
 
 
extern std::string          sss; 
extern void FFF(const AAA&, int); 
 
 
struct XXX 
{ 
        void test ( void ); 
 
 
        int     iii; 
}; 
 
 
 
 
void XXX::test ( void ) 
{ 
    AAA aaa = ( sss + sss).c_str(); 
 
    FFF( aaa, iii ); 
}