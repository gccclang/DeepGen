
template< class T >
class A
{
public:
   class B;
};

class C
{
};

template< class T >
class A< T >::B : public C
{
};