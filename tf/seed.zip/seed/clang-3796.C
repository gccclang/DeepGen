
struct A {
};

struct B {
};

int func(A) { return 11; }
int func(B) { return 22; }

int main() {
  A a;
  B b;
  return func(a) + func(b);
}