
struct A
{
  virtual void foo();
  char waste[0x1234567];
};

struct B
{
  virtual void bar();
};

struct C : public A, public B
{
  virtual void foo();
  virtual void bar();
};

void C::foo() { }
void C::bar() { }
