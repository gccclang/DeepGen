
int main()
{
    try
    {
    }
    catch (int const &foo)
    {
    }
}
