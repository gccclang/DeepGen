
struct A
{
  virtual void foo ();
};

struct B : public A
{
  B ();
  void foo () {}
};

inline A *
bar ()
{
  return new B;
}
