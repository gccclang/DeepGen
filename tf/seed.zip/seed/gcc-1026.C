
struct PSurfXYPlane
{
  PSurfXYPlane(double v1);
};


void xswap(double& x1) ;
double xxx  = 0;

PSurfXYPlane::PSurfXYPlane(double v1) 
{
  xswap(v1);
  xxx = v1;
}


void xswap (double& x1) { x1 = 2; }
extern "C" void printf (...);
int main ()
{
  PSurfXYPlane p (1);
  printf ("%lf\n", xxx);
  return 0;
}
