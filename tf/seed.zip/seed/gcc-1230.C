
extern "C" {
 void Foo();
}
#ifdef BUG
#pragma weak Random_Symbol
#endif
void Foo() { }
