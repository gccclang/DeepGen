template <int M>
unsigned long int m()
{
    unsigned long int max_value = 1;
    if (M < 64)
        max_value = (max_value << M) - 1;
    else
        max_value = ~(max_value - 1);

    return max_value;
}

int main()
{
    m<64>();
}