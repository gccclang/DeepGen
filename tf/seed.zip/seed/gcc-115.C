
template <class T>
struct Foo {
  int i;
};

struct Baz 
{
  int* j;
};

template <class T>
struct Bar : public Foo<T>, Baz {
  using Baz::j;
  char* baz () { return j; } // { dg-error "cannot convert" }
};

template <class T>
struct Bar2 : Baz {
  using Baz::j;
  char* baz () { return j; } // { dg-error "cannot convert" }
};
