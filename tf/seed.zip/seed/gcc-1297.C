
struct c0 { };
struct c2 {
    unsigned char m1;
};
struct c5 : c0, virtual c2 { };
struct c6 { };
struct c9 : c5, c6 { };
struct c10 :
    virtual c2,
    virtual c5,
    virtual c0,
    c9
{
};
struct c17 : virtual c10, c6 { };
