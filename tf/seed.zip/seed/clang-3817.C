template <int N>
void	test(int value)
{
	asm("rol %1, %0" :"=r"(value): "I"(N + 1));
}
int		main()
{
	test<2>(10);
}