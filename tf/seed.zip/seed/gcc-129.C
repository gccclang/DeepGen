
extern void foo();
extern void bar(char* );
extern char* foobar();

class C {public: ~C() {foo();}};

int main()
{
    C c;
        
    // Try to open the reserve file -- check for error
    char* rFileName = foobar();

    // Read the reserve file -- catch exceptions
    try {
        foo();
    }
    catch (...) {
        bar(rFileName);
    }
    
    foo();

}
