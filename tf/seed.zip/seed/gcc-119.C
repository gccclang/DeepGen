
void PreEvaluate(void);
int main() { PreEvaluate(); return 0; }
