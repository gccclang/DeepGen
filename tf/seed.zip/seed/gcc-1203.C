

template < class T > struct a {
  struct a1:public T {
    using T::aa;
    a1() {
      aa = 5;
    };
  };
};
struct b {
  int aa;
};
a < b >::a1 Ia;