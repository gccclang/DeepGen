
    int main()
    {
        int *a;
        (void) &a;
      
        *a = 4;
        return 0;
    }