
template <bool> struct Constraint { typedef int Result; }; 
 
template <typename T> struct IsInt; 
template <> struct IsInt<int> { static const bool value = true; }; 
 
template <typename T> 
typename Constraint<IsInt<T>::value>::Result foo(T); 
 
template <typename> 
void bar() { 
    foo(1); 
} 
 
template void bar<int> (); 