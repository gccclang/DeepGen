#include <stdio.h>
#include <new>

struct B {
  ~B() { puts("Destroying B"); }
  virtual void f() = 0;
};

struct D : public B {
  ~D() { puts("Destroying D"); }
  void f() override { }
};

int main() {
  char buffer[sizeof(D)];
  B* b = new (buffer) D;
  b->~B();  // No warning.

  B* b2 = new D;
  delete b2;  // Warning.
}