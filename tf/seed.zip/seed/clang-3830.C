class VB {
public:
  int n;
  VB (int v) { n = v; }
  VB (const VB& o) {
    n = o.n;
  }
};

class D : public virtual VB {
  int j;
public:
  D(int i1, int i2) : VB(i2) { j = i1; }
};

int main() {
  D d(1,2);
}