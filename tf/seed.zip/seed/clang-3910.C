extern "C" void abort ();

int ctor = 0;
int dtor = 0;

template <class T> struct A {
	A() {ctor++;}
	A(int) {ctor++;}
	A(const A&) {ctor++;}
	~A() {dtor++;}
	operator int() {return 0;}
};

void f() {
  A<short> a4 = 97;
}

int 
main() {
  f();

  if (!ctor || ctor != dtor)
    return 1;

  return 0;
}