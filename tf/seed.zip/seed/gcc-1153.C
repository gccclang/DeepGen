
 class eel_private_executable
 {
 public:
   virtual void read_section_descriptors() = 0;
 };

 class executable : public eel_private_executable
 {
 };


 class eel_bfd_executable : public virtual executable
 {
 public:
   virtual void read_section_descriptors();
 };


 class eel_arch_executable : public virtual executable
 {
 };

 class eel_archive_executable : public eel_arch_executable,
				public eel_bfd_executable
 {
 public:
   virtual void read_contents();
 };


 void
 eel_archive_executable::read_contents()
 {
   read_section_descriptors();
 }
