

#include <sstream>
using namespace std;
int main ()
{
   int val;
   istringstream str_vector(string("10"));
   str_vector >> val;
}