

void use_longlong ()
{
  unsigned long long x1, x2, x3; 
  // make sure it's ok with hex, decimal and octal
  x1 = 0x1b27da572ef3cd86;
  x2 = 1956772631100509574;
  x3 = 0154476645345674746606;
}

void use_longlong2 ()
{
  unsigned long long x1, x2, x3; 
  // make sure it's ok with hex, decimal and octal
  x1 = 0x1b27da572ef3cd86LL;
  x2 = 1956772631100509574LL;
  x3 = 0154476645345674746606LL;
}
