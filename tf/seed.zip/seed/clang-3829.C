
#include <algorithm>

int main() {
  int buffer[std::max(1, 2)];
  return 0;
}