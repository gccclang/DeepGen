  namespace N1 { void f() {} }
  namespace N2 { void f(int) {} using N1::f; }
  int main() { N2::f(0); }
