
#include <iostream>
#include <ctime>

int foo()
   {
   if(std::time(0) % 2) return 5;
   }

int main()
   {
   std::cout << foo() << std::endl;
   return 0;
   }