template<typename T>
struct S {
  void f() {
    int a;
  }
};

int main() {
  S<int>().f();
  S<double>().f();
}