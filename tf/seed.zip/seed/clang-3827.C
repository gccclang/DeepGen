
int main() {
  const int *cp; 
  int *p = (int *)cp;
}