
#include <iostream>
int foo(int* changeme) { return (*changeme = 100); }
int main() {
  int x=1111;
  std::cout << "foo(&x): " << foo(&x) << ", x: " << x << std::endl;
}
// BTW: there was no complaint when I used an unqualified endl instead of std::endl;
