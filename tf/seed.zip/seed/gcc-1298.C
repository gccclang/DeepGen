
class a
{
public:
	
	template<class T>
	operator T &() const
	{
		static int f;
		return f;
	}

};

int main()
{

	a const &aa = a();
}
