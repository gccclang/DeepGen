template<const char *str>
const char *baz ()
{
  return str;
}

namespace { char foo[] = "foo"; };

const char *
bar ()
{
  return baz<foo> ();
}
