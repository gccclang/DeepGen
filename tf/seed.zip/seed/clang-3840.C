
struct Foo {
	char bar_[1];

	Foo(void)
	: bar_()
	{ }
};

int
main(void)
{
	Foo a;
}