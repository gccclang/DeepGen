
namespace n1 {
struct foo{};
}

namespace n2 {
struct foo{};
}

using namespace n1;
using namespace n2;

template <typename tp>
int run(tp const & t) {
    return t.foo;
}

struct bar {
    int foo;
};

int main() {
    bar b;

    run(b);
}